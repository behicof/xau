import asyncio
from datetime import datetime
from typing import Dict, List, Union
from .management_system import UltimateManagementSystem

class ManagementInterface:
    def __init__(self):
        self.system = UltimateManagementSystem()
        self.current_view = 'dashboard'
        
        # تنظیمات رابط
        self.interface_config = {
            'update_interval': 1.0,  # seconds
            'auto_optimize': True,
            'show_notifications': True,
            'detail_level': 'complete'
        }
        
    async def run_interface(self):
        """
        اجرای رابط مدیریت
        """
        while True:
            try:
                # به‌روزرسانی داشبورد
                await self._update_dashboard()
                
                # بررسی وضعیت سیستم
                system_status = await self.system.manage_system()
                
                # نمایش اطلاعات
                self._display_status(system_status)
                
                # بهینه‌سازی خودکار
                if self.interface_config['auto_optimize']:
                    await self._auto_optimize()
                
                await asyncio.sleep(self.interface_config['update_interval'])
                
            except Exception as e:
                self._show_error(f"Interface error: {str(e)}")
    
    def _display_status(self, status: Dict):
        """
        نمایش وضعیت سیستم
        """
        if status['success']:
            print("\n=== System Status ===")
            print(f"Active Cores: {len(self.system.system_state['active_cores'])}")
            print(f"System Harmony: {self.system.system_state['system_harmony']:.2f}")
            print(f"Integration Level: {self.system.system_state['integration_level']:.2f}")
            
            if self.interface_config['detail_level'] == 'complete':
                print("\n=== Detailed Status ===")
                print(f"Activation Status: {status['activation']}")
                print(f"Harmony Level: {status['harmony']}")
                print(f"Integration Status: {status['integration']}")
                print(f"Optimization Level: {status['optimization']}")
        else:
            self._show_error(f"Status Error: {status['error']}")